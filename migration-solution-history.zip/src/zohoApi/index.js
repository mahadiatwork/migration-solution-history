import { record } from "./record";
import { auth } from "./auth";
import { file } from "./file";

export const zohoApi = { record, auth, file };
